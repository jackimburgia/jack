#include <stdio.h>

void swap(int *array, int i1, int i2);
int insert_shell(int *array, int n, int gap);
void shell_sort(int *array, int n);

int main(){

    int arr[] = {0, 5, 15, 3, 18, 7, 20, 2, 16, 1};

    swap(arr, 0, 1);

//    shell_sort(arr, 10);
//
    int x;
    for(x = 0; x < 10; x++)
        printf("%d, ", arr[x]);

    return 0;
}

void swap(int *array, int i1, int i2) {
    int temp = array[i1];
    array[i1] = array[i2];
    array[i2] = temp;
}


void shell_sort(int *array, int n) {
    int gap = n / 2;

    while (insert_shell(array, n, gap) == 1) {
        gap = gap / 2;
    }
}

int insert_shell(int *array, int n, int gap) {
    if (gap == 0) {
        return 0;
    }

    int i; int j;

    for (i = gap; i < n; i++) {
        for (j = i; j >= gap && (array[j - gap] > array[j]); j -= gap) {
            swap(array, j - gap, j);
        }
    }

    return 1;
}





