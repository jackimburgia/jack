#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// https://www.eg.bucknell.edu/~csci320/mips_web/
// http://max.cs.kzoo.edu/cs230/Resources/MIPS/MachineXL/InstructionFormats.html
// https://en.wikibooks.org/wiki/MIPS_Assembly/Instruction_Formats
// https://www.rapidtables.com/convert/number/hex-to-decimal.html

int binToDec(char* bits);
char* subString(char value[], int start, int length);
char* getRegister(int num);
int OpCode(char* instruction);
int FunctCode(char* instruction);
char *Rs(char* instruction);
char *Rt(char* instruction);
char *Rd(char* instruction);
int Shamt(char* instruction);
int ImmOff(char* instruction);
int Target(char* instruction);
char *GetMips(char* instruction);
char *Rformat1(char* instruction, char name[]);
char *Rformat2(char* instruction, char name[]);
char *Jformat1(char* instruction, char name[]);
char *Jformat2(char* instruction, char name[]);
char *Iformat1(char* instruction, char name[]);
char *Iformat2(char* instruction, char name[]);
char *Iformat3(char* instruction, char name[]);

int main(){

    // https://www.eg.bucknell.edu/~csci320/mips_web/
	//char* instruction = "00100001010010010000000000000101";
	//char* instruction = "00000001001010111000000000100000"; // add $s0, $t1, $t3
//    char* instruction = "00000001001010111000000000101010"; // slt $s0, $t1, $t3
//    char* instruction = "00000000000011001000000100000000"; // sll $s0, $t4, 4 (0x04)
//    char* instruction = "00000000000011001000000100000010"; // srl $s0, $t4, 4 (0x04)
//    char* instruction = "00000010011000000000000000001000"; // jr $s3
//    char* instruction = "00000001001010111000000000100010"; // sub $s0, $t1, $t3

    //char* instruction = "00100001100100000000000000000100"; // addi $s0, $t4, 4 (0x04)
//    char* instruction = "00010010000011000000000000000100"; // beq $s0, $t4, 4 (0x04)
    //char* instruction = "00010110000011000000000000000100"; // bne $s0, $t4, 4 (0x04)
//    char* instruction = "00001000000000000000000000000100"; // j 4 (0x04)
//    char* instruction = "10001110001010100000000000000100"; // lw $t2, 4($s1)
    //char* instruction = "10101110001010100000000000000100"; // sw $t2, 4($s1)

    //char *m = GetMips("00100001100100000000000000000100"); printf("%s\", m);; free(m);

char *m0 = GetMips("00000001001010111000000000100000"); printf("%s\n", m0); free(m0);
char *m1 = GetMips("00000001001010111000000000101010"); printf("%s\n", m1); free(m1);
char *m2 = GetMips("00000000000011001000000100000000"); printf("%s\n", m2); free(m2);
char *m3 = GetMips("00000000000011001000000100000010"); printf("%s\n", m3); free(m3);
char *m4 = GetMips("00000010011000000000000000001000"); printf("%s\n", m4); free(m4);
char *m5 = GetMips("00000001001010111000000000100010"); printf("%s\n", m5); free(m5);
char *m6 = GetMips("00100001100100000000000000000100"); printf("%s\n", m6); free(m6);
char *m7 = GetMips("00010010000011000000000000000100"); printf("%s\n", m7); free(m7);
char *m8 = GetMips("00010110000011000000000000000100"); printf("%s\n", m8); free(m8);
char *m9 = GetMips("00001000000000000000000000000100"); printf("%s\n", m9); free(m9);
char *m10 = GetMips("10001110001010100000000000000100"); printf("%s\n", m10); free(m10);
char *m11 = GetMips("10101110001010100000000000000100"); printf("%s\n", m11); free(m11);




return 0;

}

char *Rformat1(char* instruction, char name[]){
    char *rs = Rs(instruction);
    char *rt = Rt(instruction);
    char *rd = Rd(instruction);

    char *mips = malloc(17 * sizeof(char));
    strcpy(mips, name);
    strcat(mips, " ");
    strcat(mips, rd);
    strcat(mips, ", ");
    strcat(mips, rs);
    strcat(mips, ", ");
    strcat(mips, rt);

    return mips;
}

char *Rformat2(char* instruction, char name[]){
    int sa = Shamt(instruction);
    char *rt = Rt(instruction);
    char *rd = Rd(instruction);

    char *mips = malloc(26 * sizeof(char));
    strcpy(mips, name);
    strcat(mips, " ");
    strcat(mips, rd);
    strcat(mips, ", ");
    strcat(mips, rt);
    strcat(mips, ", ");

    char str[12];
    sprintf(str, "%d", sa);
    strcat(mips, str);

    return mips;
}

char *Jformat1(char* instruction, char name[]){
    int sa = Shamt(instruction);
    char *rs = Rs(instruction);

    char *mips = malloc(5 * sizeof(char));
    strcpy(mips, name);
    strcat(mips, " ");
    strcat(mips, rs);

    return mips;
}

char *Jformat2(char* instruction, char name[]){
    int tgt = Target(instruction);

    char *mips = malloc(14 * sizeof(char));
    strcpy(mips, name);
    strcat(mips, " ");

    char str[12];
    sprintf(str, "%d", tgt);
    strcat(mips, str);

    return mips;
}

char *Iformat1(char* instruction, char name[]){
    int io = ImmOff(instruction);
    char *rt = Rt(instruction);
    char *rs = Rs(instruction);

    char *mips = malloc(27 * sizeof(char));
    strcpy(mips, name);
    strcat(mips, " ");
    strcat(mips, rt);
    strcat(mips, ", ");
    strcat(mips, rs);
    strcat(mips, ", ");

    char str[12];
    sprintf(str, "%d", io);
    strcat(mips, str);

    return mips;
}

char *Iformat2(char* instruction, char name[]){
    int io = ImmOff(instruction);
    char *rt = Rt(instruction);
    char *rs = Rs(instruction);

    char *mips = malloc(27 * sizeof(char));
    strcpy(mips, name);
    strcat(mips, " ");
    strcat(mips, rs);
    strcat(mips, ", ");
    strcat(mips, rt);
    strcat(mips, ", ");

    char str[12];
    sprintf(str, "%d", io);
    strcat(mips, str);

    return mips;
}

char *Iformat3(char* instruction, char name[]){
    int io = ImmOff(instruction);
    char *rt = Rt(instruction);
    char *rs = Rs(instruction);

    char *mips = malloc(27 * sizeof(char));
    strcpy(mips, name);
    strcat(mips, " ");
    strcat(mips, rt);
    strcat(mips, ", ");

    char str[12];
    sprintf(str, "%d", io);
    strcat(mips, str);

    strcat(mips, "(");
    strcat(mips, rs);
    strcat(mips, ")");

    return mips;
}


char *GetMips(char* instruction){
	int opCode = OpCode(instruction);

	if (opCode == 0){
        int funct = FunctCode(instruction);
        if (funct == 32){
            return Rformat1(instruction, "add");
        }
        else if (funct == 42){
            return Rformat1(instruction, "slt");
        }
        else if (funct == 34){
            return Rformat1(instruction, "sub");
        }
        else if (funct == 0){
            return Rformat2(instruction, "sll");
        }
        else if (funct == 2){
            return Rformat2(instruction, "srl");
        }
        else if (funct == 8){
            return Jformat1(instruction, "jr");
        }
	}
	else if (opCode == 8){
        return Iformat1(instruction, "addi");
	}
	else if (opCode == 4){
        return Iformat2(instruction, "beq");
	}
	else if (opCode == 5){
        return Iformat2(instruction, "bne");
	}
	else if (opCode == 2){
        return Jformat2(instruction, "j");
	}
	else if (opCode == 35){
        return Iformat3(instruction, "lw");
	}
	else if (opCode == 43){
        return Iformat3(instruction, "sw");
	}
}


int Target(char* instruction){
    char *bin = subString(instruction, 6, 26);
    int code = binToDec(bin);

    free(bin);

    return code;
}

int ImmOff(char* inst){
    char *bin = subString(inst, 16, 16);
    int code = binToDec(bin);

    free(bin);

    return code;
}

int Shamt(char* instruction){
    char *bin = subString(instruction, 21, 5);
    int code = binToDec(bin);

    free(bin);

    return code;
}

char *Rd(char* instruction){
    char *bin = subString(instruction, 16, 5);
    int code = binToDec(bin);
    char *reg = getRegister(code);

    free(bin);

    return reg;
}


char *Rt(char* instruction){
    char *bin = subString(instruction, 11, 5);
    int code = binToDec(bin);
    char *reg = getRegister(code);

    free(bin);

    return reg;
}


char *Rs(char* instruction){
    char *bin = subString(instruction, 6, 5);
    int code = binToDec(bin);

    char *reg = getRegister(code);

    free(bin);

    return reg;
}

int FunctCode(char* instruction){
    char *bin = subString(instruction, 26, 6);
    int code = binToDec(bin);

    free(bin);

    return code;
}

int OpCode(char* instruction){
    char *bin = subString(instruction, 0, 6);
    int code = binToDec(bin);

    free(bin);
    free(instruction);

    return code;
}

// https://stackoverflow.com/questions/308695/how-do-i-concatenate-const-literal-strings-in-c
char* getRegister(int num){
    char *reg = malloc(5* sizeof(char));

    if (num == 0)
        strcpy(reg, "$zero");
    else if (num >= 2 && num <= 3){
        strcpy(reg, "$v");
        reg[2] = (num-2)+'0';
    }
    else if (num >= 4 && num <= 7){
        strcpy(reg, "$a");
        reg[2] = (num-4)+'0';
    }
    else if (num >= 8 && num <= 15){
        strcpy(reg, "$t");
        reg[2] = (num-8)+'0';
    }
    else if (num >= 16 && num <= 23){
        strcpy(reg, "$s");
        reg[2] = (num-16)+'0';
    }
    else if (num >= 24 && num <= 25){
        strcpy(reg, "$t");
        reg[2] = (num-16)+'0';
    }
    else if (num == 28)
        strcpy(reg, "$gp");
    else if (num == 29)
        strcpy(reg, "$sp");
    else if (num == 30)
        strcpy(reg, "$fp");
    else if (num == 31)
        strcpy(reg, "$ra");

    return reg;
}

char* subString(char *value, int start, int length){
    int i;
    char* arr;

    arr = calloc(length, sizeof(char*)+1);

    for(i = 0; i < length; i++){
        arr[i] = value[start];
        start++;
    }

    arr[i] = '\0';

    free(value);

    return arr;
}

int binToDec(char* bits){
    int x = 0;
	int sum = 0;
	int len = strlen(bits);

	for (x = 0; x < len; x++)
	{
		if (bits[x] == '1')
		{
			sum += 1 << (len - x - 1);
		}
	}

	return sum;
}



//printf(binToDec("100001111") == 271 ? "true\n" : "false\n");
//printf(binToDec("11101111") == 239 ? "true\n" : "false\n");
//printf(binToDec("1111001") == 121 ? "true\n" : "false\n");
//printf(binToDec("110001011") == 395 ? "true\n" : "false\n");
//printf(binToDec("10011000") == 152 ? "true\n" : "false\n");
//printf(binToDec("10011010") == 154 ? "true\n" : "false\n");
//printf(binToDec("111010011") == 467 ? "true\n" : "false\n");
//printf(binToDec("11100100") == 228 ? "true\n" : "false\n");
//printf(binToDec("1110") == 14 ? "true\n" : "false\n");
//printf(binToDec("100100001") == 289 ? "true\n" : "false\n");
//printf(binToDec("100110") == 38 ? "true\n" : "false\n");
//printf(binToDec("110111010") == 442 ? "true\n" : "false\n");
//printf(binToDec("100100011") == 291 ? "true\n" : "false\n");
//printf(binToDec("11100") == 28 ? "true\n" : "false\n");
//printf(binToDec("111010010") == 466 ? "true\n" : "false\n");
//printf(binToDec("111100000") == 480 ? "true\n" : "false\n");
//printf(binToDec("11101101") == 237 ? "true\n" : "false\n");
//printf(binToDec("111110011") == 499 ? "true\n" : "false\n");
//printf(binToDec("111000101") == 453 ? "true\n" : "false\n");
//printf(binToDec("110101101") == 429 ? "true\n" : "false\n");
//printf(binToDec("11001100") == 204 ? "true\n" : "false\n");
//printf(binToDec("111001110") == 462 ? "true\n" : "false\n");
//printf(binToDec("11001110") == 206 ? "true\n" : "false\n");
//printf(binToDec("11101010") == 234 ? "true\n" : "false\n");
//printf(binToDec("100110110") == 310 ? "true\n" : "false\n");
//printf(binToDec("110110100") == 436 ? "true\n" : "false\n");


//
//	int opCode = OpCode(instruction);
//    //printf("Op Code = %d\n", opCode);
//
//	if (opCode == 0){
//        // look at the function
//        int funct = FunctCode(instruction);
//        printf("Funct = %d\n", funct);
//        if (funct == 32){
//            // add
////            printf("add\n");
//            char *rs = Rs(instruction);
//            char *rt = Rt(instruction);
//            char *rd = Rd(instruction);
//
////            printf("rd = %s\n", rd);
////            printf("rs = %s\n", rs);
////            printf("rt = %s\n", rt);
//
//            char *mips = malloc(17 * sizeof(char));
//            strcpy(mips, "add ");
//            strcat(mips, rd);
//            strcat(mips, ", ");
//            strcat(mips, rs);
//            strcat(mips, ", ");
//            strcat(mips, rt);
//
//            printf("%s\n", mips);
//        }
//        else if (funct == 42){
//            // slt
//            char *rs = Rs(instruction);
//            char *rt = Rt(instruction);
//            char *rd = Rd(instruction);
//
//            char *mips = malloc(17 * sizeof(char));
//            strcpy(mips, "slt ");
//            strcat(mips, rd);
//            strcat(mips, ", ");
//            strcat(mips, rs);
//            strcat(mips, ", ");
//            strcat(mips, rt);
//
//            printf("%s\n", mips);
//        }
//        else if (funct == 0){
//            // sll
//            int sa = Shamt(instruction);
//            char *rt = Rt(instruction);
//            char *rd = Rd(instruction);
//
//            char *mips = malloc(26 * sizeof(char));
//            strcpy(mips, "sll ");
//            strcat(mips, rd);
//            strcat(mips, ", ");
//            strcat(mips, rt);
//            strcat(mips, ", ");
//
//            char str[12];
//            sprintf(str, "%d", sa);
//            strcat(mips, str);
//
//            printf("%s\n", mips);
//        }
//        else if (funct == 2){
//            // srl
//            int sa = Shamt(instruction);
//            char *rt = Rt(instruction);
//            char *rd = Rd(instruction);
//
//            char *mips = malloc(26 * sizeof(char));
//            strcpy(mips, "srl ");
//            strcat(mips, rd);
//            strcat(mips, ", ");
//            strcat(mips, rt);
//            strcat(mips, ", ");
//
//            char str[12];
//            sprintf(str, "%d", sa);
//            strcat(mips, str);
//
//            printf("%s\n", mips);
//        }
//        else if (funct == 8){
//            // jr
//            int sa = Shamt(instruction);
//            char *rs = Rs(instruction);
//
//            char *mips = malloc(5 * sizeof(char));
//            strcpy(mips, "jr ");
//            strcat(mips, rs);
//
//            printf("%s\n", mips);
//        }
//        else if (funct == 34){
//            // sub
//            char *rs = Rs(instruction);
//            char *rt = Rt(instruction);
//            char *rd = Rd(instruction);
//
//            char *mips = malloc(17 * sizeof(char));
//            strcpy(mips, "sub ");
//            strcat(mips, rd);
//            strcat(mips, ", ");
//            strcat(mips, rs);
//            strcat(mips, ", ");
//            strcat(mips, rt);
//
//            printf("%s\n", mips);
//        }
//	}
//	else if (opCode == 8){
//        // addi
//
//        int io = ImmOff(instruction);
//        char *rt = Rt(instruction);
//        //printf("addi");
//        char *rs = Rs(instruction);
//
//        char *mips = malloc(27 * sizeof(char));
//        strcpy(mips, "addi ");
//        strcat(mips, rt);
//        strcat(mips, ", ");
//        strcat(mips, rs);
//        strcat(mips, ", ");
//
//        char str[12];
//        sprintf(str, "%d", io);
//        strcat(mips, str);
//
//        printf("%s\n", mips);
//	}
//	else if (opCode == 4){
//        // beq
//        int io = ImmOff(instruction);
//        char *rt = Rt(instruction);
//        char *rs = Rs(instruction);
//
//        char *mips = malloc(27 * sizeof(char));
//        strcpy(mips, "beq ");
//        strcat(mips, rs);
//        strcat(mips, ", ");
//        strcat(mips, rt);
//        strcat(mips, ", ");
//
//        char str[12];
//        sprintf(str, "%d", io);
//        strcat(mips, str);
//
//        printf("%s\n", mips);
//	}
//	else if (opCode == 5){
//        // bne
//        int io = ImmOff(instruction);
//        char *rt = Rt(instruction);
//        char *rs = Rs(instruction);
//
//        char *mips = malloc(27 * sizeof(char));
//        strcpy(mips, "bne ");
//        strcat(mips, rs);
//        strcat(mips, ", ");
//        strcat(mips, rt);
//
//	int opCode = OpCode(instruction);
//    //printf("Op Code = %d\n", opCode);
//
//	if (opCode == 0){
//        // look at the function
//        int funct = FunctCode(instruction);
//        printf("Funct = %d\n", funct);
//        if (funct == 32){
//            // add
////            printf("add\n");
//            char *rs = Rs(instruction);
//            char *rt = Rt(instruction);
//            char *rd = Rd(instruction);
//
////            printf("rd = %s\n", rd);
////            printf("rs = %s\n", rs);
////            printf("rt = %s\n", rt);
//
//            char *mips = malloc(17 * sizeof(char));
//            strcpy(mips, "add ");
//            strcat(mips, rd);
//            strcat(mips, ", ");
//            strcat(mips, rs);
//            strcat(mips, ", ");
//            strcat(mips, rt);
//
//            printf("%s\n", mips);
//        }
//        else if (funct == 42){
//            // slt
//            char *rs = Rs(instruction);
//            char *rt = Rt(instruction);
//            char *rd = Rd(instruction);
//
//            char *mips = malloc(17 * sizeof(char));
//            strcpy(mips, "slt ");
//            strcat(mips, rd);
//            strcat(mips, ", ");
//            strcat(mips, rs);
//            strcat(mips, ", ");
//            strcat(mips, rt);
//
//            printf("%s\n", mips);
//        }
//        else if (funct == 0){
//            // sll
//            int sa = Shamt(instruction);
//            char *rt = Rt(instruction);
//            char *rd = Rd(instruction);
//
//            char *mips = malloc(26 * sizeof(char));
//            strcpy(mips, "sll ");
//            strcat(mips, rd);
//            strcat(mips, ", ");
//            strcat(mips, rt);
//            strcat(mips, ", ");
//
//            char str[12];
//            sprintf(str, "%d", sa);
//            strcat(mips, str);
//
//            printf("%s\n", mips);
//        }
//        else if (funct == 2){
//            // srl
//            int sa = Shamt(instruction);
//            char *rt = Rt(instruction);
//            char *rd = Rd(instruction);
//
//            char *mips = malloc(26 * sizeof(char));
//            strcpy(mips, "srl ");
//            strcat(mips, rd);
//            strcat(mips, ", ");
//            strcat(mips, rt);
//            strcat(mips, ", ");
//
//            char str[12];
//            sprintf(str, "%d", sa);
//            strcat(mips, str);
//
//            printf("%s\n", mips);
//        }
//        else if (funct == 8){
//            // jr
//            int sa = Shamt(instruction);
//            char *rs = Rs(instruction);
//
//            char *mips = malloc(5 * sizeof(char));
//            strcpy(mips, "jr ");
//            strcat(mips, rs);
//
//            printf("%s\n", mips);
//        }
//        else if (funct == 34){
//            // sub
//            char *rs = Rs(instruction);
//            char *rt = Rt(instruction);
//            char *rd = Rd(instruction);
//
//            char *mips = malloc(17 * sizeof(char));
//            strcpy(mips, "sub ");
//            strcat(mips, rd);
//            strcat(mips, ", ");
//            strcat(mips, rs);
//            strcat(mips, ", ");
//            strcat(mips, rt);
//
//            printf("%s\n", mips);
//        }
//	}
//	else if (opCode == 8){
//        // addi
//
//        int io = ImmOff(instruction);
//        char *rt = Rt(instruction);
//        //printf("addi");
//        char *rs = Rs(instruction);
//
//        char *mips = malloc(27 * sizeof(char));
//        strcpy(mips, "addi ");
//        strcat(mips, rt);
//        strcat(mips, ", ");
//        strcat(mips, rs);
//        strcat(mips, ", ");
//
//        char str[12];
//        sprintf(str, "%d", io);
//        strcat(mips, str);
//
//        printf("%s\n", mips);
//	}
//	else if (opCode == 4){
//        // beq
//        int io = ImmOff(instruction);
//        char *rt = Rt(instruction);
//        char *rs = Rs(instruction);
//
//        char *mips = malloc(27 * sizeof(char));
//        strcpy(mips, "beq ");
//        strcat(mips, rs);
//        strcat(mips, ", ");
//        strcat(mips, rt);
//        strcat(mips, ", ");
//
//        char str[12];
//        sprintf(str, "%d", io);
//        strcat(mips, str);
//
//        printf("%s\n", mips);
//	}
//	else if (opCode == 5){
//        // bne
//        int io = ImmOff(instruction);
//        char *rt = Rt(instruction);
//        char *rs = Rs(instruction);
//
//        char *mips = malloc(27 * sizeof(char));
//        strcpy(mips, "bne ");
//        strcat(mips, rs);
//        strcat(mips, ", ");
//        strcat(mips, rt);
//        strcat(mips, ", ");
//
//        char str[12];
//        sprintf(str, "%d", io);
//        strcat(mips, str);
//
//        printf("%s\n", mips);
//	}
//	else if (opCode == 2){
//        // j
//        int tgt = Target(instruction);
//
//        char *mips = malloc(14 * sizeof(char));
//        strcpy(mips, "j ");
//
//        char str[12];
//        sprintf(str, "%d", tgt);
//        strcat(mips, str);
//
//        printf("%s\n", mips);
//	}
//	else if (opCode == 35){
//        // lw
//        int io = ImmOff(instruction);
//        char *rt = Rt(instruction);
//        char *rs = Rs(instruction);
//
//        char *mips = malloc(27 * sizeof(char));
//        strcpy(mips, "lw ");
//        strcat(mips, rt);
//        strcat(mips, ", ");
//
//        char str[12];
//        sprintf(str, "%d", io);
//        strcat(mips, str);
//
//        strcat(mips, "(");
//        strcat(mips, rs);
//        strcat(mips, ")");
//
//
//
//        printf("%s\n", mips);
//	}
//	else if (opCode == 43){
//        // sw
//        int io = ImmOff(instruction);
//        char *rt = Rt(instruction);
//        char *rs = Rs(instruction);
//
//        char *mips = malloc(27 * sizeof(char));
//        strcpy(mips, "sw ");
//        strcat(mips, rt);
//        strcat(mips, ", ");
//
//        char str[12];
//        sprintf(str, "%d", io);
//        strcat(mips, str);
//
//        strcat(mips, "(");
//        strcat(mips, rs);
//        strcat(mips, ")");
//
//
//
//        printf("%s\n", mips);
//	}
//
//
//
//
//
//    free(instruction);
//
//        strcat(mips, ", ");
//
//        char str[12];
//        sprintf(str, "%d", io);
//        strcat(mips, str);
//
//        printf("%s\n", mips);
//	}
//	else if (opCode == 2){
//        // j
//        int tgt = Target(instruction);
//
//        char *mips = malloc(14 * sizeof(char));
//        strcpy(mips, "j ");
//
//        char str[12];
//        sprintf(str, "%d", tgt);
//        strcat(mips, str);
//
//        printf("%s\n", mips);
//	}
//	else if (opCode == 35){
//        // lw
//        int io = ImmOff(instruction);
//        char *rt = Rt(instruction);
//        char *rs = Rs(instruction);
//
//        char *mips = malloc(27 * sizeof(char));
//        strcpy(mips, "lw ");
//        strcat(mips, rt);
//        strcat(mips, ", ");
//
//        char str[12];
//        sprintf(str, "%d", io);
//        strcat(mips, str);
//
//        strcat(mips, "(");
//        strcat(mips, rs);
//        strcat(mips, ")");
//
//
//
//        printf("%s\n", mips);
//	}
//	else if (opCode == 43){
//        // sw
//        int io = ImmOff(instruction);
//        char *rt = Rt(instruction);
//        char *rs = Rs(instruction);
//
//        char *mips = malloc(27 * sizeof(char));
//        strcpy(mips, "sw ");
//        strcat(mips, rt);
//        strcat(mips, ", ");
//
//        char str[12];
//        sprintf(str, "%d", io);
//        strcat(mips, str);
//
//        strcat(mips, "(");
//        strcat(mips, rs);
//        strcat(mips, ")");
//
//
//
//        printf("%s\n", mips);
//	}
//
//
//
//
//
//    free(instruction);

