#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define LENGTH 32
#define false 0
#define true 1


int BinToInt(char* bits);
char* subString(char value[], int start, int length);
char* getRegister(int num);
int OpCode(char* instruction);
int FunctCode(char* instruction);
char *Rs(char* instruction);
char *Rt(char* instruction);
char *Rd(char* instruction);
int Shamt(char* instruction);
int ImmOff(char* instruction);
int Target(char* instruction);
char *GetMips(char* instruction);
char *Rformat1(char* instruction, char name[]);
char *Rformat2(char* instruction, char name[]);
char *Jformat1(char* instruction, char name[]);
char *Jformat2(char* instruction, char name[]);
char *Iformat1(char* instruction, char name[]);
char *Iformat2(char* instruction, char name[]);
char *Iformat3(char* instruction, char name[]);
int check(char* bits);


// We will take the bitstring as a command line argument.
int main(int argc, char **argv) {

    // Make sure we have at least one argument.
    if (argc < 2) {
        fprintf(stderr, "No argument found\n");
        return -1;
    }

    // Get a pointer to the argument.
    char *instruction = argv[1];

    if (!check(instruction)) {
        fprintf(stderr, "Invalid bit string\n");
        return -2;
    }

    char *m0 = GetMips(instruction);
    printf("%s\n", m0);



    return 0;

}

// Checks that the char array is 32 bits long
// and only has 0 and 1 in it.
int check(char* bits) {
    if (strlen(bits) != LENGTH) {
        return false;
    }
    int i;
    for (i = 0; i < LENGTH; i++) {
        if (bits[i] != '0' && bits[i] != '1') {
            return false;
        }
    }

    return true;
}

// Converts the binary instruction to the MIPS format
char *GetMips(char* instruction){
	int opCode = OpCode(instruction);

	if (opCode == 0){
        int funct = FunctCode(instruction);
        if (funct == 32){
            return Rformat1(instruction, "add");
        }
        else if (funct == 42){
            return Rformat1(instruction, "slt");
        }
        else if (funct == 34){
            return Rformat1(instruction, "sub");
        }
        else if (funct == 0){
            return Rformat2(instruction, "sll");
        }
        else if (funct == 2){
            return Rformat2(instruction, "srl");
        }
        else if (funct == 8){
            return Jformat1(instruction, "jr");
        }
	}
	else if (opCode == 8){
        return Iformat1(instruction, "addi");
	}
	else if (opCode == 4){
        return Iformat2(instruction, "beq");
	}
	else if (opCode == 5){
        return Iformat2(instruction, "bne");
	}
	else if (opCode == 2){
        return Jformat2(instruction, "j");
	}
	else if (opCode == 35){
        return Iformat3(instruction, "lw");
	}
	else if (opCode == 43){
        return Iformat3(instruction, "sw");
	}
}

// parses the Target value
int Target(char* instruction){
    char *bin = subString(instruction, 6, 26);
    int code = BinToInt(bin);

    return code;
}

// parses both the immediate and offset values
int ImmOff(char* inst){
    char *bin = subString(inst, 16, 16);
    int code = BinToInt(bin);

    return code;
}

// parses the SHAMT value
int Shamt(char* instruction){
    char *bin = subString(instruction, 21, 5);
    int code = BinToInt(bin);

    return code;
}

// parses the RD value
char *Rd(char* instruction){
    char *bin = subString(instruction, 16, 5);
    int code = BinToInt(bin);
    char *reg = getRegister(code);

    return reg;
}

// parses the RT value
char *Rt(char* instruction){
    char *bin = subString(instruction, 11, 5);
    int code = BinToInt(bin);
    char *reg = getRegister(code);

    return reg;
}

// parses the RS value
char *Rs(char* instruction){
    char *bin = subString(instruction, 6, 5);
    int code = BinToInt(bin);

    char *reg = getRegister(code);

    return reg;
}

// parses the funct code
int FunctCode(char* instruction){
    char *bin = subString(instruction, 26, 6);
    int code = BinToInt(bin);

    return code;
}

// Parses the op code
int OpCode(char* instruction){
    char *bin = subString(instruction, 0, 6);
    int code = BinToInt(bin);

    return code;
}

// Returns the register string based on th number
char* getRegister(int num){
    char *reg = malloc(5* sizeof(char));

    if (num == 0)
        strcpy(reg, "$zero");
    else if (num >= 2 && num <= 3){
        strcpy(reg, "$v");
        reg[2] = (num-2)+'0';
    }
    else if (num >= 4 && num <= 7){
        strcpy(reg, "$a");
        reg[2] = (num-4)+'0';
    }
    else if (num >= 8 && num <= 15){
        strcpy(reg, "$t");
        reg[2] = (num-8)+'0';
    }
    else if (num >= 16 && num <= 23){
        strcpy(reg, "$s");
        reg[2] = (num-16)+'0';
    }
    else if (num >= 24 && num <= 25){
        strcpy(reg, "$t");
        reg[2] = (num-16)+'0';
    }
    else if (num == 28)
        strcpy(reg, "$gp");
    else if (num == 29)
        strcpy(reg, "$sp");
    else if (num == 30)
        strcpy(reg, "$fp");
    else if (num == 31)
        strcpy(reg, "$ra");

    return reg;
}

// Returns a substring (similar to Java, C#, Javascript, etc)
char* subString(char *value, int start, int length){
    int i;
    char* arr;

    arr = calloc(length, sizeof(char*)+1);

    for(i = 0; i < length; i++){
        arr[i] = value[start];
        start++;
    }

    arr[i] = '\0';

    return arr;
}

// Converts a string representing a binary number to int format
int BinToInt(char* bits){
    int x = 0;
	int sum = 0;
	int len = strlen(bits);

	for (x = 0; x < len; x++)
	{
		if (bits[x] == '1')
		{
			sum += 1 << (len - x - 1);
		}
	}

	return sum;
}


char *Rformat1(char* instruction, char name[]){
    char *rs = Rs(instruction);
    char *rt = Rt(instruction);
    char *rd = Rd(instruction);

    char *mips = malloc(17 * sizeof(char));
    strcpy(mips, name);
    strcat(mips, " ");
    strcat(mips, rd);
    strcat(mips, ", ");
    strcat(mips, rs);
    strcat(mips, ", ");
    strcat(mips, rt);

    return mips;
}

char *Rformat2(char* instruction, char name[]){
    int sa = Shamt(instruction);
    char *rt = Rt(instruction);
    char *rd = Rd(instruction);

    char *mips = malloc(26 * sizeof(char));
    strcpy(mips, name);
    strcat(mips, " ");
    strcat(mips, rd);
    strcat(mips, ", ");
    strcat(mips, rt);
    strcat(mips, ", ");

    char str[12];
    sprintf(str, "%d", sa);
    strcat(mips, str);

    return mips;
}

char *Jformat1(char* instruction, char name[]){
    int sa = Shamt(instruction);
    char *rs = Rs(instruction);

    char *mips = malloc(5 * sizeof(char));
    strcpy(mips, name);
    strcat(mips, " ");
    strcat(mips, rs);

    return mips;
}

char *Jformat2(char* instruction, char name[]){
    int tgt = Target(instruction);

    char *mips = malloc(14 * sizeof(char));
    strcpy(mips, name);
    strcat(mips, " ");

    char str[12];
    sprintf(str, "%d", tgt);
    strcat(mips, str);

    return mips;
}

char *Iformat1(char* instruction, char name[]){
    int io = ImmOff(instruction);
    char *rt = Rt(instruction);
    char *rs = Rs(instruction);

    char *mips = malloc(27 * sizeof(char));
    strcpy(mips, name);
    strcat(mips, " ");
    strcat(mips, rt);
    strcat(mips, ", ");
    strcat(mips, rs);
    strcat(mips, ", ");

    char str[12];
    sprintf(str, "%d", io);
    strcat(mips, str);

    return mips;
}

char *Iformat2(char* instruction, char name[]){
    int io = ImmOff(instruction);
    char *rt = Rt(instruction);
    char *rs = Rs(instruction);

    char *mips = malloc(27 * sizeof(char));
    strcpy(mips, name);
    strcat(mips, " ");
    strcat(mips, rs);
    strcat(mips, ", ");
    strcat(mips, rt);
    strcat(mips, ", ");

    char str[12];
    sprintf(str, "%d", io);
    strcat(mips, str);

    return mips;
}

char *Iformat3(char* instruction, char name[]){
    int io = ImmOff(instruction);
    char *rt = Rt(instruction);
    char *rs = Rs(instruction);

    char *mips = malloc(27 * sizeof(char));
    strcpy(mips, name);
    strcat(mips, " ");
    strcat(mips, rt);
    strcat(mips, ", ");

    char str[12];
    sprintf(str, "%d", io);
    strcat(mips, str);

    strcat(mips, "(");
    strcat(mips, rs);
    strcat(mips, ")");

    return mips;
}


