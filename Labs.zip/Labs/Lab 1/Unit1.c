#include <stdio.h>

//#define

int addit(int x , int y);
char *GetName();
swap(int v[], int k);

int main(){
    int nums[2];
    nums[0] = 99;
    nums[1] = 3;

    int x;

    for(x = 0; x < 2; x++){
        printf("%d\n", nums[x]);
    }

    swap(nums, 0);

    for(x = 0; x < 2; x++){
        printf("%d\n", nums[x]);
    }
//    const char myName[] = "Jack Imburgia a";
//    puts(myName);
//    printf("%s\n", myName);

//    char name = GetName();
//    printf("%s", GetName());

//    const int cnt = 4;
//
//    char name[cnt] = "JACK";
//
//    printf("%s\n", name);
}

swap(int v[], int k)
{
    int temp;
    temp = v[k];
    v[k] = v[k+1];
    v[k+1] = temp;
}

int addit(int x , int y){
    int result = x + y;
    return result;
}

char *GetName(){
    static char name[] = "Jack";
    return name;
}

//
//
//#define HIGHEST 10000
//#define MAX 15
//
//Operation(int x, char op, int y);
//
// main()
// {
//
//
//    char buf[MAX];
//         /*
//    fgets(buf, MAX, stdin);
//    */
//    // TODO - change int numbers to double or float?
//    // TODO - add comments
//    // TODO - Add validation to other questions
//
//    int x;
//    char c;
//    int y;
//    int result;
//    int count;
//    char extra;#include <stdio.h>
//
//void arrayAddition(int A[], int B[], int N, int output[]);
//
//int main() {
//	int A[] = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
//	int B[] = { 9, 8, 7, 6, 5, 4, 3, 2, 1 };
//	int output[9];
//	int N = 9;
//
//	arrayAddition(A, B, N, output);
//}
//
//void arrayAddition(int A[], int B[], int N, int output[]) {
//	int i; int atemp; int btemp;
//	for (i = 0; i < N; i++)
//	{
//		atemp = A[i];
//		btemp = B[i];
//		output[i] = A[i] + B[i];
//		printf("%d\n", output[i]);
//	}
//}
//
//    //scanf("%d", &x);
//
//    while(*fgets(buf, MAX, stdin) != '\n') {
//        // process
//        count = sscanf(buf, "%d %c %d %c", &x, &c, &y, &extra);
//        //printf("count: %d\n", count);
//        if (count == 3){
//            //printf("process: %d %c %d\n", x, c, y);
//            result = Operation(x, c, y);
//            printf("%d\n", result);
//        }
//        else{
//            printf("Invalid formula: must be in the format '3 + 5' - try again\n");
//        }
//    //
//
//
//    }
//
//    printf("done");
//
//    /*
//    if (buf[0] == '\n')
//        printf('carriage return!');
//    else
//        printf("string is: %s\n", buf);
//*/
//    /*
//        int x;
//    char c;
//    int y;
//    printf("Enter the equation: ");
//
//
////char d = getchar() ;
//    int p = scanf("%d %c %d", &x, &c, &y);
//    printf("Output = %d\n", p);
//    //char d = getchar() ;
//
//
//
//    scanf("%d", &x);
//    scanf(" %c", &c);
//    scanf(" %d", &y);
//
//
//    printf("You typed: %d\n", x);
//    printf("You typed: %c\n", c);
//    printf("You typed: %d\n", y);
//    */
//    /*
//
//
//    */
//
//
//
//
// }
//
// int Operation(int x, char op, int y)
// {
//    if(op == '+')
//        return x + y;
//    else if (op == '-')
//        return x - y;
//    else if (op == '*')
//        return x * y;
//    else if (op == '/')
//        return y == 0 ? 0 : x / y;
//    else if (op == '%')
//        return x % y;
//    else
//        return 99999;
// }
//
// int GetNum(int x){
//    return x;
// }
//     /*
//    double nc;
//    for (nc = 0; getchar() != EOF; ++nc)           ;
//
//    printf("%.0f\n", nc);
//
//    int c;
//    c = getchar();
//    while (c != EOF) {
//        putchar(c);
//        c = getchar();
//    }
//    */
//    /*int x = getchar();
//    printf("%d\n");
//*/
