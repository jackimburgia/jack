#include <stdio.h>
#include <math.h>

// define constant for PI only if it hasn't been defined already
#ifndef M_PI
#define M_PI acos(-1.0)
#endif

main() {
	float radius;   // the radius entered
	float diameter; // calculated diameter
	float circumference; // calculated circumference

	int count;      // count of values retrieved from the console

	printf("Enter the radius of a circle:");

	// Get the user entered value
	count = scanf("%f", &radius);

	// test whether a valid radius was displayed
	if (count == 1){
        // the radius is valid; calculate and display
        diameter = 2 * radius;
        circumference = 2 * M_PI * radius;

        printf("Diameter = %f\n", diameter);
        printf("Circumference = %f\n", circumference);
	}
	else{
        printf("Invalid radius entered");
	}
}
