#include <stdio.h>

void arrayAddition(int A[], int B[], int N, int output[]);

int main() {
	int A[] = { 1, 2, 3, 4, 5, 6, 7, 8, 9 }; // first array
	int B[] = { 9, 8, 7, 6, 5, 4, 3, 2, 1 }; // second array
	int output[9]; // array to store the sum of corresponding array elements
	int N = 9; // number of elements in the array

	// display the array addition
	arrayAddition(A, B, N, output);
}

// adds the corresponding values of two arrays and stores in output array
void arrayAddition(int A[], int B[], int N, int output[]) {
	int i; int atemp; int btemp;
	// loop through each element in the array
	for (i = 0; i < N; i++)
	{
		atemp = A[i];
		btemp = B[i];
		// store the value to the output array
		output[i] = A[i] + B[i];
		// display
		printf("%d\n", output[i]);
	}
}

