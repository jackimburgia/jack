#include <stdio.h>

main() {
	int n;  // the integer entered
	int i;  // counter in line for loop
	int x;  // counter in line output for loop

	int isOdd; // whether it's an odd line number
	char character; // the character to display on the line
	int count; // count of valid numbers entered

	// get the number of lines from the console
	printf("Enter an integer: ");
	count = scanf("%d", &n);

	// display the lines if the number of lines entered is valid
	//  and is greater than 0
	if (count == 1 && n > 0){
        // display each line
        for (i = 0; i < n; i++)
        {
            // set the character of line based on odd / even row
            isOdd = (i % 2) == 1;
            character = isOdd == 1 ? '^' : '*';

            // display the values in the line
            for(x = 0; x <= i; x++)
                printf("%c", character);

            printf("\n");
        }
	}

}


