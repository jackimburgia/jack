#include <stdio.h>

void fibonacci(int n);
int fibonacciAt(int x);

main() {
	int k; // number of fibonacci elements to display

	// get the number of elements from the console
	printf("Enter the fibonacci sequence position (one-based):");
	scanf("%d", &k);

	// display the fibonacci sequence
	fibonacci(k);
}

// displays the first k number of fibonacci elements
void fibonacci(int n) {
	int i; // counter for loop
	for (i = 0; i < n; i++) {
        // get the fibonacci element at a specific position
        //  and display it
		int fib = fibonacciAt(i);
		printf("%d\n", fib);
	}
}

// returns the fibonacci element at a specific position
int fibonacciAt(int i) {
	if (i < 2)
		return i;
	else
		return fibonacciAt(i - 1) + fibonacciAt(i - 2);
}
