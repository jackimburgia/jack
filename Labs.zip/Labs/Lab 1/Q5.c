#include <stdio.h>
#include <stdbool.h>
#define MAX 25

int Operation(int x, char op, int y);
bool IsValidOperator(char op);
bool IsEquationValid(char op, int count);

main()
{
    char buf[MAX];

    int x;      // first number in the operation
    char op;    // the operator
    int y;      // second number in the operation
    int result; // stores the result of the equation entered

    int count;  // number of values successfully retrieved from the console
    char extra; // stores any value after the values for the equation; used for validation

    bool isValid; // whether the equation is valid or not

    // continue retrieving values from the console until enter is clicked by itself
    while(*fgets(buf, MAX, stdin) != '\n') {
        // attempt to retrieve the values of the equation
        count = sscanf(buf, "%d %c %d %c", &x, &op, &y, &extra);

        // test whether the equation entered is valid
        isValid = IsEquationValid(op, count);

        if (isValid){
            // equation entered is valid

            // get the result of the equation entered and display it
            result = Operation(x, op, y);
            printf("%d\n", result);
        }
        else{
            // formula keyed in is not valid; try again
            printf("Invalid formula: must be in the format '3 + 5' - try again\n");
        }
    }

}

// performs the specified operation on the two numbers
int Operation(int x, char op, int y)
{
    if(op == '+')
        return x + y;
    else if (op == '-')
        return x - y;
    else if (op == '*')
        return x * y;
    else if (op == '/')
        return y == 0 ? 0 : x / y;
    else if (op == '%')
        return x % y;
    else
        return 0;
}

// returns whether the equation is valid
bool IsEquationValid(char op, int count)
{
    bool isCountGood = count == 3; // must have 3 values retrieved
    bool isOpValid = IsValidOperator(op); // operator must be valid

    return isCountGood &&
        isOpValid;
}

// returns whether operator argument is valid
bool IsValidOperator(char op)
{
    switch(op){
        case '+':
        case '-':
        case '*':
        case '/':
        case '%':
            return true;
    }
    return false;
}


