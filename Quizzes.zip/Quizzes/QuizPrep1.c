# https://beginnersbook.com/2014/01/c-pointers/

#include <stdio.h>

main() {
    int *xp;
    int x = 11;
    xp = &x;

    printf("%d\n", x);
    printf("%d\n", *xp);

    x = 55;

    printf("%d\n", x);
    printf("%d\n", *xp);

    *xp = 34;

    printf("%d\n", x);
    printf("%d\n", *xp);
}
